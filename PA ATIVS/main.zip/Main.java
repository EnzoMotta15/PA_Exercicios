/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

import java.util.Scanner;


public class Main 
    {
  public static void main(String[] args) 
    {
        
    String nome;
    int idade;
    Double nota1, nota2, media;
    int resposta=1;
    
    while (resposta == 1)
    {
        
    Scanner teclado = new Scanner (System.in);
    System.out.println("Qual seu nome");
    nome = teclado.next();
    
    System.out.println("Qual a sua idade");
    idade = teclado.nextInt();
    
    System.out.println("Insira a Nota 1");
    nota1 = teclado.nextDouble();
    
    System.out.println("Insira a Nota 2");
    nota2 = teclado.nextDouble();
    
    media = (nota1+nota2)/2;
    

    if (idade >=18)
        {
            System.out.println("Você é Maior de Idade");
        }
        
    else if (idade <18)
        {
            System.out.println("Você é menor de Idade (Um nenezão) ");
        }
    
    if (media >= 5)
        {
        System.out.println("Sua Média é: "+ media);
        System.out.println("Você foi Aprovado");
        }
    
    else if (media <=5)
        {
        System.out.println("Sua media é : "+ media);
        System.out.println("Ligue para Seus Pais");
        System.out.println("Houston We Have a Problem!");
        }
    
    System.out.println("Deseja Executar o Programa Novamente? Digite 1 - Sim 2 - Não");
        resposta = teclado.nextInt();
    
  


    

        
        
        
    }
}
}
    
    