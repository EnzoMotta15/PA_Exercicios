/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class frequencia
{

	public static void main(String[] args) {
	   
	
	
		System.out.println("Hello World");

		int aula1 = 80;
		int aula2 = 60;
		int presenca;
	    float media;
	    
	  	media = (aula1 + aula2) /100;

		System.out.println("A porcentagem da presença é:"+ media);

	}
}
