import java.util.Scanner; 


public class Main {
  public static void main(String[] args) {

    Scanner teclado = new Scanner (System.in);
    System.out.println("Mostre os números ímpares de 1 até 100");
   int i = 100;
   if ()
    
    while (1 < 100);
    {
      System.out.println(resposta);
      resposta = resposta + 1;
    }  
    
    
    
  }
}
